package RM;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Medicines{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblmid,lblmname,lblcost,lbldos,lbldname;
	private JTextField txtmid,txtmname,txtcost,txtdos,txtdname;
	private Choice dname;
	
	private List MEDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Medicines(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblmid=new JLabel("Medicine ID");
		lblmname=new JLabel("Medicine Name");
		lblcost=new JLabel("Price");
		lbldos=new JLabel("Dosage");
		lbldname=new JLabel("Disease Name");
		
		
		txtmid=new JTextField(8);
		txtmname=new JTextField(30);
		txtcost=new JTextField(8);
		txtdos=new JTextField(8);
		dname=new Choice();
		txtdname=new JTextField(25);
		
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737100","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadMedIDs() {
		try {
			MEDList.removeAll();
			rs=statement.executeQuery("select * from medicines");
			while(rs.next()) {
				MEDList.add(rs.getString("medicine_id")+"->"+rs.getString("medicine_name"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	
	public void loaddis() {
	try {
		dname.removeAll();
		rs=statement.executeQuery("select * from diseases");
		while(rs.next()) {
			dname.add(rs.getString("disease_name"));
		}
		}
	catch(SQLException e) {
		displaySQLErrors(e);
	}
	}
	


	public void buildGUI() {
		
		
		if(logininto.user.equals("admin")) {
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("submit");
				loaddis();
				
				txtmid.setText(null);
				txtmname.setText(null);
				txtcost.setText(null);
				txtdos.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,2));
				 
				 p1.add(lblmid);
				 p1.add(txtmid);
				 p1.add(lblmname);
				 p1.add(txtmname);
				 p1.add(lblcost);
				 p1.add(txtcost);
				 p1.add(lbldos);
				 p1.add(txtdos);
				 p1.add(lbldname);
				 p1.add(dname);
				/* p1.add(insertButton);
				
					p1.setBackground(Color.orange) ;
				 p1.setBounds(100,100,300,400);
				*/
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				 p2 = new JPanel(new FlowLayout());
					
					 MEDList=new List(10);
					 loadMedIDs();
					 p2.add(MEDList);
					 p2.setBackground(Color.WHITE);
					 p2.setBounds(125,320,300,180);  
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO medicines VALUES("+txtmid.getText()+",'"+txtmname.getText()+"','"+txtcost.getText()+"','"+txtdos.getText()+"','"+dname.getSelectedItem()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loadMedIDs() ;
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				//deleteButton.setSize(1,1);
				txtmid.setText(null);
				txtmname.setText(null);
				txtcost.setText(null);
				txtdos.setText(null);
				txtdname.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,2));
				 
				 p1.add(lblmid);
				 p1.add(txtmid);
				 p1.add(lblmname);
				 p1.add(txtmname);
				 p1.add(lblcost);
				 p1.add(txtcost);
				 p1.add(lbldos);
				 p1.add(txtdos);
				 p1.add(lbldname);
				 p1.add(txtdname);
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				 p2 = new JPanel(new FlowLayout());
					
					 MEDList=new List(10);
					 loadMedIDs();
					 p2.add(MEDList);
					 p2.setBackground(Color.WHITE);
					 p2.setBounds(125,320,300,180);  
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 MEDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from medicines");
								StringTokenizer st=new StringTokenizer(MEDList.getSelectedItem(),"->");
								String p=st.nextToken();
								//String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("medicine_id").equals(p))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtmid.setText(rs.getString("medicine_id"));
									txtmname.setText(rs.getString("medicine_name"));
									txtcost.setText(rs.getString("price"));
									txtdos.setText(rs.getString("dosage"));
									txtdname.setText(rs.getString("disease_name"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
						StringTokenizer st=new StringTokenizer(MEDList.getSelectedItem(),"->");
				
					String query="DELETE FROM medicines WHERE medicine_ID="+st.nextToken();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadMedIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("modify");
				txtmid.setText(null);
				txtmname.setText(null);
				txtcost.setText(null);
				txtdos.setText(null);
				txtdname.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,2));
				 p1.add(lblmid);
				 p1.add(txtmid);
				 p1.add(lblmname);
				 p1.add(txtmname);
				 p1.add(lblcost);
				 p1.add(txtcost);
				 p1.add(lbldos);
				 p1.add(txtdos);
				 p1.add(lbldname);
				 p1.add(txtdname);
				 
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				 p2 = new JPanel(new FlowLayout());
					
					 MEDList=new List(10);
					 loadMedIDs();
					 p2.add(MEDList);
					 p2.setBackground(Color.WHITE);
					 p2.setBounds(125,320,300,180);  
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 MEDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from medicines");
								StringTokenizer st=new StringTokenizer(MEDList.getSelectedItem(),"->");
								String p=st.nextToken();
								//String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("medicine_id").equals(p))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtmid.setText(rs.getString("medicine_id"));
									txtmname.setText(rs.getString("medicine_name"));
									txtcost.setText(rs.getString("price"));
									txtdos.setText(rs.getString("dosage"));
									txtdname.setText(rs.getString("disease_name"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
									StringTokenizer st=new StringTokenizer(MEDList.getSelectedItem(),"->");
								String query="update medicines set medicine_id="+txtmid.getText()+",medicine_name='"+txtmname.getText()+"',price='"+txtcost.getText()+"',dosage="+txtdos.getText()+",disease_name='"+txtdname.getText()+"' WHERE medicine_id="+st.nextToken();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadMedIDs() ;
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		}
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Medicines view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.WHITE) ;p2.setBackground(Color.WHITE) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Medicine details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("medicine_id");
						       model.addColumn("medicine_name");
						       model.addColumn("price");
						       model.addColumn("dosage");
						       model.addColumn("disease_name");
						      
						       try {
									
									rs=statement.executeQuery("select * from medicines");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("medicine_id"), rs.getString("medicine_name"),rs.getString("price"),rs.getString("dosage"),rs.getString("disease_name")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	


