package RM;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class users {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton LoginButton,deleteButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbllogin_id,lblusername,lblage,lblgender,lblcnum;
	private JTextField txtlogin_id,txtusername,txtage,txtgender,txtcnum;
	private Choice login_id;
	
	private List usersList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public users(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lbllogin_id=new JLabel("login_ID");
		lblusername=new JLabel("username");
		lblage=new JLabel("Age");
		lblgender=new JLabel("Gender");
		lblcnum=new JLabel("Contact Number");
		login_id=new Choice();
		txtlogin_id=new JTextField(30);
		txtusername=new JTextField(30);
		txtage=new JTextField(8);
		txtgender=new JTextField(5);
		txtcnum=new JTextField(10);
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737100","vasavi");
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadusers() {
		try {
			usersList.removeAll();
			rs=statement.executeQuery("select * from users");
			while(rs.next()) {
				usersList.add(rs.getString("login_id")+"->"+rs.getString("username"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	
	public void loadLogins() {
		try {
			login_id.removeAll();
			rs=statement.executeQuery("select * from login");
			while(rs.next()) {
				login_id.add(rs.getString("login_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	public void buildGUI() {
		if(logininto.user.equals("admin")) {
		LoginButton=new JButton("submit");
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				loadLogins();
				//txtlogin_id.setText(null);
				txtusername.setText(null);
				txtage.setText(null); 
				txtgender.setText(null);
				txtcnum.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				   
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,2));
				 p1.add(lbllogin_id);
				 p1.add(login_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblage);
				 p1.add(txtage);
				 p1.add(lblgender);
				 p1.add(txtgender);
				 p1.add(lblcnum);
				 p1.add(txtcnum);
				 p3=new JPanel(new FlowLayout());
				 p3.add(LoginButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 usersList=new List(10);
					 loadusers();
					 p2.add(usersList);p2.setBackground(Color.WHITE) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
			
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 LoginButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO users VALUES('"+login_id.getSelectedItem()+"','"+txtusername.getText()+"','"+txtage.getText()+"','"+txtgender.getText()+"',"+txtcnum.getText()+")";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully"); 
					loadusers();
					
					System.out.println("done");
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				
				txtlogin_id.setText(null);
				txtusername.setText(null);
				txtage.setText(null); 
				txtgender.setText(null);
				txtcnum.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,2));
				 p1.setLayout(new GridLayout(5,2));
				 p1.add(lbllogin_id);
				 p1.add(txtlogin_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblage);
				 p1.add(txtage);
				 p1.add(lblgender);
				 p1.add(txtgender);
				 p1.add(lblcnum);
				 p1.add(txtcnum); 
				
				// p1.add(deleteButton);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 usersList=new List(10);
					 loadusers();
					 p2.add(usersList);p2.setBackground(Color.WHITE) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 usersList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from users");
								StringTokenizer st=new StringTokenizer(usersList.getSelectedItem(),"->");
								String p=st.nextToken();
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(p))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtlogin_id.setText(rs.getString("login_id"));
									txtusername.setText(rs.getString("username"));
									txtage.setText(rs.getString("age")); 
									txtgender.setText(rs.getString("gender"));
									txtcnum.setText(rs.getString("contact_number"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					//String password=JOptionPane.showInputDialog(p,"Enter the password");
					
					//txtpwd.setText(password);
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM users WHERE login_id="+txtlogin_id.getText()+" AND username='"+txtusername.getText()+"' AND age='"+txtage.getText()+"' AND gender='"+txtgender.getText()+"' AND contact_number="+txtcnum.getText()+"";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadusers();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		}
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("modify");
				txtlogin_id.setText(null);
				txtusername.setText(null);
				txtage.setText(null); 
				txtgender.setText(null);
				txtcnum.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,2));
				 
				 p1.add(lbllogin_id);
				 p1.add(txtlogin_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblage);
				 p1.add(txtage);
				 p1.add(lblgender);
				 p1.add(txtgender);
				 p1.add(lblcnum);
				 p1.add(txtcnum);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				 p2 = new JPanel(new FlowLayout());
					
					 usersList=new List(10);
					 //loadusers();
					 if(logininto.user.equals("user")) {
						 usersList.removeAll();
						 usersList.add(logininto.user1);
					 }
					 if(logininto.user.equals("admin")){
						loadusers(); 
					 }
					 p2.add(usersList);
					 p2.setBackground(Color.WHITE);
					 p2.setBounds(125,320,300,180);  
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 usersList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from users");
								StringTokenizer st=new StringTokenizer(usersList.getSelectedItem(),"->");
								String p=st.nextToken();
								//String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(p))
									break;
								}
								if (!rs.isAfterLast()) 
								{

									txtlogin_id.setText(rs.getString("login_id"));
									txtusername.setText(rs.getString("username"));
									txtage.setText(rs.getString("age"));
									txtgender.setText(rs.getString("gender"));
									txtcnum.setText(rs.getString("contact_number"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
							 if(logininto.user.equals("admin")) {
								loadusers(); 
									
								String query="update users set username='"+txtusername.getText()+"',age='"+txtage.getText()+"',gender='"+txtgender.getText()+"',contact_number="+txtcnum.getText()+" WHERE login_id="+txtlogin_id.getText()+"";
									
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadusers() ;
								}
							 if(logininto.user.equals("user")) {
									usersList.removeAll();
									usersList.add(logininto.user1);
									//String contact_number=JOptionPane.showInputDialog(p,"Enter the new contact number");
									
									
									//txtcnum.setText(contact_number);
										
									String query="update users set username='"+txtusername.getText()+"',age='"+txtage.getText()+"',gender='"+txtgender.getText()+"',contact_number="+txtcnum.getText()+" WHERE login_id="+txtlogin_id.getText()+"";
									//String query=" update users set contact_number='"+contact_number+"' where login_id='"+txtlogin_id.getText()+"'";
									int i=statement.executeUpdate(query);
									
									
									JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");
									}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("User view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.WHITE) ;p2.setBackground(Color.WHITE) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("User details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("login_id");
						       model.addColumn("username");
						       model.addColumn("age");
						       model.addColumn("gender");
						       model.addColumn("contact_number");
						       try {
									
									rs=statement.executeQuery("select * from users");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("login_id"),rs.getString("username"),rs.getString("age"),rs.getString("gender"),rs.getString("contact_number")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
