package RM;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class diseases{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbldname,lbltod;
	private JTextField txtdname,txttod;
	
	private List DISList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public diseases(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lbldname=new JLabel("Disease  Name");
		lbltod=new JLabel("Type of disease");
		
		
		
		txtdname=new JTextField(15);
		txttod=new JTextField(15);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737100","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loaddis() {
		try {
			DISList.removeAll();
			rs=statement.executeQuery("select * from diseases");
			while(rs.next()) {
			DISList.add(rs.getString("disease_name"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		if(logininto.user.equals("admin")) {
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("submit");
				txtdname.setText(null);
				txttod.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(2,2));
				 p1.add(lbldname);
				 p1.add(txtdname);
				 p1.add(lbltod);
				 p1.add(txttod);
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				
					 
				 
				
				 p2 = new JPanel(new FlowLayout());
					
					 DISList=new List(10);
					 loaddis();
					 p2.add(DISList);p2.setBackground(Color.WHITE) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO diseases VALUES('"+txtdname.getText()+"','"+txttod.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loaddis();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				
				txtdname.setText(null);
				txttod.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(2,2));
				 p1.add(lbldname);
				 p1.add(txtdname);
				 p1.add(lbltod);
				 p1.add(txttod);
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				 p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.WHITE) ;
				 p1.setBounds(115,80,300,250);
				 
				
					 
				// p1.setBounds(100,100,500,300);
				
				 p2 = new JPanel(new FlowLayout());
					
					 DISList=new List(10);
					 loaddis();
					 p2.add(DISList);p2.setBackground(Color.WHITE) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 p.setLayout(new BorderLayout());
				 frame.add(p);
				 frame.setSize(800,800);
				 frame.validate();
				  DISList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from diseases");
								while (rs.next()) 
								{
									if (rs.getString("disease_name").equals(DISList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtdname.setText(rs.getString("disease_name"));
									txttod.setText(rs.getString("type_of_disease"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});				
				 
				 
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM diseases WHERE disease_name='"+txtdname.getText()+"'";
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loaddis();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("modify");
				txtdname.setText(null);
				txttod.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(2,2));
				 p1.add(lbldname);
				 p1.add(txtdname);
				 p1.add(lbltod);
				 p1.add(txttod);
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				 p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.WHITE) ;
				 p1.setBounds(115,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
					
					 DISList=new List(10);
					 loaddis();
					 p2.add(DISList);p2.setBackground(Color.WHITE) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 p.setLayout(new BorderLayout());
					
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				  DISList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from diseases");
								while (rs.next()) 
								{
									if (rs.getString("disease_name").equals(DISList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtdname.setText(rs.getString("disease_name"));
									txttod.setText(rs.getString("type_of_disease"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
							 	loaddis();
							 	String disease_name=JOptionPane.showInputDialog(p,"Enter the new disease");
							 	txtdname.setText(disease_name);
								
								//int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								//if(a==JOptionPane.YES_OPTION){  
							 	String query="update diseases set disease_name='"+disease_name+"' where type_of_disease='"+txttod.getText()+"' ";
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loaddis();
								}
						 
								
								
							
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		}
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Diseases view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.WHITE) ;p2.setBackground(Color.WHITE) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Diseases details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("Disease Name");
						       model.addColumn("Type Of Disease");
						       
						      
						      
						       try {
									
									rs=statement.executeQuery("select * from diseases");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("disease_name"), rs.getString("type_of_disease")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	
