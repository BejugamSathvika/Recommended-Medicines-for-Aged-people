package RM;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Login {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton LoginButton,deleteButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbllogin_id,lblpwd,lblut;
	private JTextField txtlogin_id,txtpwd,txtut;
	private List users_idList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Login(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lbllogin_id=new JLabel("Login_ID");
		lblpwd=new JLabel("Password");
		lblut=new JLabel("User_Type");
		
		txtlogin_id=new JTextField(30);
		txtpwd=new JPasswordField(8);
		txtut=new JTextField(20);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737100","vasavi");
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadLogins() {
		try {
			users_idList.removeAll();
			rs=statement.executeQuery("select * from login");
			while(rs.next()) {
				users_idList.add(rs.getString("login_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		if(logininto.user.equals("admin")) {
		LoginButton=new JButton("submit");
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				txtlogin_id.setText(null);
				txtpwd.setText(null); 
				txtut.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				   
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lbllogin_id);
				 p1.add(txtlogin_id);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblut);
				 p1.add(txtut);
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(LoginButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 users_idList=new List(10);
					 loadLogins();
					 p2.add(users_idList);p2.setBackground(Color.WHITE) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
			
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 LoginButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO Login VALUES('"+txtlogin_id.getText()+"','"+txtpwd.getText()+"','"+txtut.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully"); 
					loadLogins();
					
					System.out.println("done");
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				
				txtlogin_id.setText(null);
				txtpwd.setText(null);
				txtut.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lbllogin_id);
				 p1.add(txtlogin_id);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblut);
				 p1.add(txtut);
				
				// p1.add(deleteButton);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 users_idList=new List(10);
					 loadLogins();
					 p2.add(users_idList);p2.setBackground(Color.WHITE) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 users_idList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from login");
								StringTokenizer st=new StringTokenizer(users_idList.getSelectedItem(),"->");
								String p=st.nextToken();
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(p))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtlogin_id.setText(rs.getString("login_id"));
									txtpwd.setText(rs.getString("password")); 
									txtut.setText(rs.getString("user_type"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					//String query="DELETE FROM Login WHERE login_id="+txtlogin_id.getText()+"AND PASSWORD='"+txtpwd.getText()+"'";
						StringTokenizer st=new StringTokenizer(users_idList.getSelectedItem(),"->");
						
						String query="DELETE FROM login WHERE login_id="+st.nextToken();
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadLogins();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
	}
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("modify");
				txtlogin_id.setText(null);
				
				txtpwd.setText(null); 
				txtut.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lbllogin_id);
				 p1.add(txtlogin_id);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblut);
				 p1.add(txtut);
				 
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 users_idList=new List(10);
					 //loadLogins();
					 if(logininto.user.equals("user")) {
						 users_idList.removeAll();
						 users_idList.add(logininto.user1);
					 }
					 if(logininto.user.equals("admin")) {
						 loadLogins();
					 }
					 p2.add(users_idList);
					 p2.add(users_idList);p2.setBackground(Color.WHITE) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 users_idList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from login");
								//StringTokenizer st=new StringTokenizer(users_idList.getSelectedItem(),"->");
								//String p=st.nextToken();
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(users_idList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtlogin_id.setText(rs.getString("login_id"));
									txtpwd.setText(rs.getString("password"));
									txtut.setText(rs.getString("user_type"));
								
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					if(logininto.user.equals("admin")) {
					loadLogins();
					
						String password=JOptionPane.showInputDialog(p,"Enter the new password");
						
						
						txtpwd.setText(password);
					 String query=" update login set password='"+password+"' where login_id='"+txtlogin_id.getText()+"'";
					
					 int i=statement.executeUpdate(query);
					
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					loadLogins();
					
					}
				
				if(logininto.user.equals("user")) {
					users_idList.removeAll();
					users_idList.add(logininto.user1);  
					String password2=JOptionPane.showInputDialog(p,"Enter the new password");
					
					
					txtpwd.setText(password2);
					 String query=" update Login set password='"+password2+"' where login_id='"+txtlogin_id.getText()+"'";
					
					 int i=statement.executeUpdate(query);
					 users_idList.removeAll();
						users_idList.add(logininto.user1);
					
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					//loadLogins();
				
				}
				}
				catch(SQLException updateException){
					
					displaySQLErrors(updateException);
				}
				
				 }
			
			
				 	});
			}
			});
	
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Login view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.WHITE) ;p2.setBackground(Color.WHITE) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Login details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("login_id");
						       model.addColumn("password");
						       model.addColumn("user_type");
						      
						       try {
									
									rs=statement.executeQuery("select * from login");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("login_id"),rs.getString("password"),rs.getString("user_type")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}