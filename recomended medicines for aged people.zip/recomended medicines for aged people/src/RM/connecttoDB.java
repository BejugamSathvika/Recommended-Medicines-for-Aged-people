package RM;
import java.sql.*;
public class connecttoDB{
	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection( "jdbc:oracle:thin:@localhost:1521:xe","it19737100","vasavi");
			return conn;
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return null;
	}
}