package RM;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class RMUI extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JMenuBar mnu;
	
	private JMenu mnuLogin;
	private JMenu mnuuser;
	private JMenu mnudiseases;
	private JMenu mnuMedicines;
	private JMenu mnuMedicines_manufacturer;
	
	private JMenuItem insert1,update1,delete1,view1;
	private JMenuItem insert3,update3,delete3,view3;
	private JMenuItem insert4,update4,delete4,view4;
	private JMenuItem insert5,update5,delete5,view5;
	private JMenuItem insert6,update6,delete6,view6;
	
	private JLabel labelName;

	
	private static JPanel p0,p1;
	
	
	void initialize() {
		mnu=new JMenuBar();
		
		mnuLogin= new JMenu("Login");
		mnuuser= new JMenu("User");
		mnudiseases= new JMenu("Diseases");
		mnuMedicines= new JMenu("Medicines");
		mnuMedicines_manufacturer= new JMenu("Medicines_manufacturer");
		labelName=new JLabel("RECOMMENDED MEDICINES FOR AGED PEOPLE");
		 p1=new JPanel();
		p0=new JPanel();
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
		delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
		insert3=new JMenuItem("Insert");
		update3=new JMenuItem("Update");
		delete3=new JMenuItem("Delete");
		view3=new JMenuItem("View");
		insert4=new JMenuItem("Insert");
		update4=new JMenuItem("Update");
		delete4=new JMenuItem("Delete");
		view4=new JMenuItem("View");
		insert5=new JMenuItem("Insert");
		update5=new JMenuItem("Update");
		delete5=new JMenuItem("Delete");
		view5=new JMenuItem("View");
		insert6=new JMenuItem("Insert");
		update6=new JMenuItem("Update");
		delete6=new JMenuItem("Delete");
		view6=new JMenuItem("View");
		
	}
	void addComponentsToFrame() {
		if(logininto.user.equals("admin")) {
		mnuLogin.add(insert1);
		 mnuLogin.add(delete1);
		 mnuLogin.add(update1);
		 mnuLogin.add(view1);
		 mnuuser.add(insert3);
		 mnuuser.add(delete3);
		 mnuuser.add(update3);
		 mnuuser.add(view3);
		 mnudiseases.add(insert4);
		 mnudiseases.add(delete4);
		 mnudiseases.add(update4);
		 mnudiseases.add(view4);
		 mnuMedicines.add(insert5);
		 mnuMedicines.add(delete5);
		 mnuMedicines.add(update5);
		 mnuMedicines.add(view5);
		 mnuMedicines_manufacturer.add(insert6);
		 mnuMedicines_manufacturer.add(delete6);
		 mnuMedicines_manufacturer.add(update6);
		 mnuMedicines_manufacturer.add(view6);
		 mnu.add(mnuLogin);
		 mnu.add(mnuuser);
		 mnu.add(mnudiseases);
		 mnu.add(mnuMedicines);
		 mnu.add(mnuMedicines_manufacturer);
		}
		
		else if(logininto.user.equals("user"))
		{
			mnuLogin.add(update1);
			mnuuser.add(update3);
			//mnuuser.add(view3);
			mnudiseases.add(view4);
			mnuMedicines.add(view5);
			mnuMedicines_manufacturer.add(view6);
			mnu.add(mnuLogin);
			 mnu.add(mnuuser);
			 mnu.add(mnudiseases);
			 mnu.add(mnuMedicines);
			 mnu.add(mnuMedicines_manufacturer);
		}
		
		 setJMenuBar(mnu); 
		 p1.add(labelName);p1.setAlignmentY(CENTER_ALIGNMENT); 
		 p1.setBounds(500,500,800,100);	
		p0.add(p1);
		 p0.setBackground(Color.GRAY);
		 add(p0);
	}
void closeWindow(){
		try {
			int a=JOptionPane.showConfirmDialog(this,"Are you sure want to Recommended Medicines for Aged People:");
			if(a==JOptionPane.YES_OPTION){  
				JOptionPane.showMessageDialog(this,
					    "Thank you!\nRecommended Medicines for Aged People","Quit",
					    JOptionPane.WARNING_MESSAGE);
				System.exit(0);
			}
			else if (a== JOptionPane.NO_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
			else if (a== JOptionPane.CANCEL_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		}
			catch(Exception e) {
				System.out.println(e);
				}
	}
void register() {
		Login log=new Login(p0,RMUI.this,insert1,delete1,update1,view1);
		log.buildGUI();
		users user=new users(p0,RMUI.this,insert3,delete3,update3,view3); 
		user.buildGUI();
		diseases dis=new diseases(p0,RMUI.this,insert4,delete4,update4,view4); 
		dis.buildGUI();
		Medicines med=new Medicines(p0,RMUI.this,insert5,delete5,update5,view5); 
		med.buildGUI();
		medicine_manufacturer comp=new medicine_manufacturer(p0,RMUI.this,insert6,delete6,update6,view6); 
		comp.buildGUI();
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				closeWindow();
			} 
		}); 
		
}
public RMUI() {
		initialize();
		addComponentsToFrame();
		register();
		pack();
		setTitle("Recommended Medicines for Aged People");
		setSize(800,800);
		setVisible(true);
	}
}


