package RM;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class medicine_manufacturer{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblcid,lblcname,lbladd,lblmid;
	private JTextField txtcid,txtcname,txtadd,txtmid;
	
	private List MidmList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public medicine_manufacturer(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblcid=new JLabel("Company ID");
		lblcname=new JLabel("Company Name");
		lbladd=new JLabel("Address");
		lblmid=new JLabel("Medicine ID");
		
		
		
		txtcid=new JTextField(15);
		txtcname=new JTextField(15);
		txtadd=new JTextField(8);
		txtmid=new JTextField(15);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737100","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadMedmIDs() {
		try {
			MidmList.removeAll();
			rs=statement.executeQuery("select * from medicine_manufacturer");
			while(rs.next()) {
				MidmList.add(rs.getString("company_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("submit");
				txtcid.setText(null);
				txtcname.setText(null);
				txtadd.setText(null);
				txtmid.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblcid);
				 p1.add(txtcid);
				 p1.add(lblcname);
				 p1.add(txtcname);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 p1.add(lblmid);
				 p1.add(txtmid);
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.WHITE) ;
				 
				
					 
				 
				
				 p2 = new JPanel(new FlowLayout());
					
					 MidmList=new List(10);
					 loadMedmIDs();
					 p2.add(MidmList);p2.setBackground(Color.WHITE) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO medicine_manufacturer VALUES("+txtcid.getText()+",'"+txtcname.getText()+"','"+txtadd.getText()+"',"+txtmid.getText()+")";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loadMedmIDs();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				
				txtcid.setText(null);
				txtcname.setText(null);
				txtadd.setText(null);
				txtmid.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblcid);
				 p1.add(txtcid);
				 p1.add(lblcname);
				 p1.add(txtcname);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 p1.add(lblmid);
				 p1.add(txtmid);
				 
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				 p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.WHITE) ;
				 p1.setBounds(115,80,300,250);
				 
				
					 
				// p1.setBounds(100,100,500,300);
				
				 p2 = new JPanel(new FlowLayout());
					
					 MidmList=new List(10);
					 loadMedmIDs();
					 p2.add(MidmList);p2.setBackground(Color.WHITE) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 p.setLayout(new BorderLayout());
				 frame.add(p);
				 frame.setSize(800,800);
				 frame.validate();
				  MidmList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from medicine_manufacturer");
								while (rs.next()) 
								{
									if (rs.getString("company_id").equals(MidmList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtcid.setText(rs.getString("company_id"));
									txtcname.setText(rs.getString("company_name"));
									txtadd.setText(rs.getString("address"));
									txtmid.setText(rs.getString("medicine_id"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});				
				 
				 
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM medicine_manufacturer WHERE company_id="+txtcid.getText()+"";
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadMedmIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("modify");
				txtcid.setText(null);
				txtcname.setText(null);
				txtadd.setText(null);
				txtmid.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblcid);
				 p1.add(txtcid);
				 p1.add(lblcname);
				 p1.add(txtcname);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 p1.add(lblmid);
				 p1.add(txtmid);
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.BLACK);
				 p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.WHITE) ;
				 p1.setBounds(115,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
					
					 MidmList=new List(10);
					 loadMedmIDs();
					 p2.add(MidmList);p2.setBackground(Color.WHITE) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 p.setLayout(new BorderLayout());
					
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				  MidmList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from medicine_manufacturer");
								while (rs.next()) 
								{
									if (rs.getString("company_id").equals(MidmList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtcid.setText(rs.getString("company_id"));
									txtcname.setText(rs.getString("company_name"));
									txtadd.setText(rs.getString("address"));
									txtmid.setText(rs.getString("medicine_id"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
							 	loadMedmIDs();
							 	String address=JOptionPane.showInputDialog(p,"Enter the new company Address");
							 	txtadd.setText(address);
								
								//int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								//if(a==JOptionPane.YES_OPTION){  
								String query="update medicine_manufacturer set address='"+address+"'where company_id="+txtcid.getText();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadMedmIDs();
								}
						 
								
								
							
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Medicine Manufacturer view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.WHITE) ;p2.setBackground(Color.WHITE) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Medicine Manufacturer details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("Company ID");
						       model.addColumn("Company Name");
						       model.addColumn("Address");
						       model.addColumn("Medicine ID");
						       
						      
						      
						       try {
									
									rs=statement.executeQuery("select * from medicine_manufacturer");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("company_id"), rs.getString("company_name"),rs.getString("address"),rs.getString("medicine_id")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	

