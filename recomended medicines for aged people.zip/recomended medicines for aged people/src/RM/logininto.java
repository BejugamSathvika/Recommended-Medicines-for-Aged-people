package RM;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import RM.*;
import java.sql.*;
import javax.sql.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class logininto extends JFrame{

	private JFrame recommendedmedicines;
	private JTextField txtLoginId;
	private JPasswordField txtPassword;
	//private JTextField txtUserName;
	private JPanel contentPane;
	public static String user,user1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					logininto window = new logininto();
					window.recommendedmedicines.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				} 
			}
		});
	}

	/**
	 * Create the application.
	 */
	public logininto() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	JButton btnLogin;
	JButton btnSignup;
	private void initialize() {
		
		
		
		recommendedmedicines = new JFrame();
		recommendedmedicines.setTitle("Recommended Medicines For Aged people");
		recommendedmedicines.setBounds(100, 100, 450, 300);
		recommendedmedicines.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		recommendedmedicines.getContentPane().setLayout(null);
		
				
		JMenuBar menuBar = new JMenuBar();
		recommendedmedicines.setJMenuBar(menuBar);
		
		
		JMenu mnNewMenu = new JMenu("Log In");
		mnNewMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				btnLogin.setVisible(true);
				btnSignup.setVisible(false);
				
			}
		});
		
		JMenu mnNewMenu1 = new JMenu("Signup");
		mnNewMenu1.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				btnLogin.setVisible(false);
				btnSignup.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu);
		menuBar.add(mnNewMenu1);
		
		txtLoginId = new JTextField();
		txtLoginId.setBounds(198, 47, 96, 20);
		recommendedmedicines.getContentPane().add(txtLoginId);
		txtLoginId.setColumns(10);
		
		
		
		JLabel lblNewLabel = new JLabel("Login Id");
		lblNewLabel.setBounds(76, 50, 84, 14);
		recommendedmedicines.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(76, 88, 84, 14);
		recommendedmedicines.getContentPane().add(lblNewLabel_1);
		
		
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean isValidUser=false;
				try {
					connecttoDB connect = new connecttoDB();
					Connection con = connect.getConnection();
					Statement stmt=con.createStatement();
					user1=txtLoginId.getText();
					//String txt = "select login_id,password,user_type from login where login_id = '"+txtLoginId.getText()+"' and password ='"+new String(txtPassword.getPassword())"'";
					//System.out.println(txt);
					String txt = "select login_id,password,user_type from login where login_id = '"+txtLoginId.getText()+"' and password ='"+new String(txtPassword.getPassword())+"'";
					ResultSet rs=stmt.executeQuery(txt);
					if(rs.next()) {
						isValidUser = true;
						user=rs.getString(3);
						
					}
					rs.close();
					
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				if(isValidUser) {
					//JOptionPane.showMessageDialog(null,"Valid User");
					RMUI h=new RMUI();
					//login code here
				}
				else {
					JOptionPane.showMessageDialog(null,"Invalid User");
				}
				
			}
		});
		btnLogin.setBounds(150, 160, 89, 23);
		recommendedmedicines.getContentPane().add(btnLogin);
		
		btnSignup = new JButton("Signup");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					connecttoDB connect = new connecttoDB();
					Connection con = connect.getConnection();
					Statement stmt=con.createStatement();
					String txt1 = "insert into login (login_id,password,user_type) values('"+txtLoginId.getText()+"' ,'"+new String(txtPassword.getPassword())+"','"+"user"+"')";
					//System.out.println(txt);
					ResultSet rs1=stmt.executeQuery(txt1);
					
					String txt = "select login_id,password,user_type from login where login_id = '"+txtLoginId.getText()+"' and password ='"+new String(txtPassword.getPassword())+"'";
					ResultSet rs=stmt.executeQuery(txt);
					user1=txtLoginId.getText();
					if(rs.next()) {
						JOptionPane.showMessageDialog(null,"Sign in successful");
						user=rs.getString(3);
						RMUI r=new RMUI();
					}
					rs.close();
					
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				
			}
		});
		btnSignup.setBounds(150, 160, 89, 23);
		recommendedmedicines.getContentPane().add(btnSignup);
		
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(198, 85, 96, 20);
		recommendedmedicines.getContentPane().add(txtPassword);
	}
}