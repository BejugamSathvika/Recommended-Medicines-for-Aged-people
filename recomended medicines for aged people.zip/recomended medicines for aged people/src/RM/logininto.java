package RM;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import RM.*;
import java.sql.*;
import javax.sql.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class logininto extends JFrame{

	private JFrame recommendedmedicines;
	private JTextField txtLoginId;
	private JPasswordField txtPassword;
	private JTextField txtUserName;
	private JPanel contentPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					logininto window = new logininto();
					window.recommendedmedicines.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				} 
			}
		});
	}

	/**
	 * Create the application.
	 */
	public logininto() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	JButton btnLogin;
	JButton btnSignup;
	JLabel lblNewLabel_2;
	private void initialize() {
		
		
		
		recommendedmedicines = new JFrame();
		recommendedmedicines.setTitle("Recommended Medicines For Aged people");
		recommendedmedicines.setBounds(100, 100, 450, 300);
		recommendedmedicines.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		recommendedmedicines.getContentPane().setLayout(null);
		
				
		JMenuBar menuBar = new JMenuBar();
		recommendedmedicines.setJMenuBar(menuBar);
		
		
		JMenu mnNewMenu = new JMenu("Log In");
		mnNewMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				btnLogin.setVisible(true);
				btnSignup.setVisible(false);
				txtUserName.setVisible(false);
				lblNewLabel_2.setVisible(false);
				
			}
		});
		
		JMenu mnNewMenu1 = new JMenu("Signup");
		mnNewMenu1.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				btnLogin.setVisible(false);
				btnSignup.setVisible(true);
				txtUserName.setVisible(true);
				lblNewLabel_2.setVisible(true);
				
			}
		});
		menuBar.add(mnNewMenu);
		menuBar.add(mnNewMenu1);
		
		txtLoginId = new JTextField();
		txtLoginId.setBounds(198, 47, 96, 20);
		recommendedmedicines.getContentPane().add(txtLoginId);
		txtLoginId.setColumns(10);
		
		txtUserName = new JTextField();
		txtUserName.setBounds(198, 126, 96, 20);
		recommendedmedicines.getContentPane().add(txtUserName);
		txtUserName.setColumns(10);
		txtUserName.setVisible(false);
		
		JLabel lblNewLabel = new JLabel("Login Id");
		lblNewLabel.setBounds(76, 50, 84, 14);
		recommendedmedicines.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(76, 88, 84, 14);
		recommendedmedicines.getContentPane().add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("User Name");
		lblNewLabel_2.setBounds(76, 126, 84, 14);
		recommendedmedicines.getContentPane().add(lblNewLabel_2);
		lblNewLabel_2.setVisible(false);
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean isValidUser=false;
				try {
					connecttoDB connect = new connecttoDB();
					Connection con = connect.getConnection();
					Statement stmt=con.createStatement();
					String txt = "select login_id,password from login where login_id = '"+txtLoginId.getText()+"' and password ='"+new String(txtPassword.getPassword())+"'";
					//System.out.println(txt);
					ResultSet rs=stmt.executeQuery(txt);
					if(rs.next()) {
						isValidUser = true;
					}
					rs.close();
					
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				if(isValidUser) {
					//JOptionPane.showMessageDialog(null,"Valid User");
					RMUI h=new RMUI();
					//login code here
				}
				else {
					JOptionPane.showMessageDialog(null,"Invalid User");
				}
				
			}
		});
		btnLogin.setBounds(150, 160, 89, 23);
		recommendedmedicines.getContentPane().add(btnLogin);
		
		btnSignup = new JButton("Signup");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					connecttoDB connect = new connecttoDB();
					Connection con = connect.getConnection();
					Statement stmt=con.createStatement();
					String txt = "insert into login (login_id,username,password) values('"+txtLoginId.getText()+"','"+txtUserName.getText()+"' ,'"+new String(txtPassword.getPassword())+"')";
					//System.out.println(txt);
					ResultSet rs=stmt.executeQuery(txt);
					if(rs.next()) {
						JOptionPane.showMessageDialog(null,"Sign in successful");
						RMUI r=new RMUI();
					}
					rs.close();
					
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				
			}
		});
		btnSignup.setBounds(150, 160, 89, 23);
		recommendedmedicines.getContentPane().add(btnSignup);
		
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(198, 85, 96, 20);
		recommendedmedicines.getContentPane().add(txtPassword);
	}
}
